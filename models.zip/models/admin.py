from models.user import User

class Administrator(User):
    def __init__(self, user_id, name, email, password):
        super().__init__(user_id, name, email, password, role="admin")

    def create_course(self, course_data):
        # عملیات ساخت دوره جدید را انجام می‌دهد (در بخش JSONHandler اضافه می‌کنیم)
        pass
