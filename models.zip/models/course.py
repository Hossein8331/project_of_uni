class Course:
    def __init__(self, id, name, instructor, time_slots, capacity, content):
        self.id = id
        self.name = name
        self.instructor = instructor
        self.time_slots = time_slots
        self.capacity = capacity
        self.content = content
        self.enrolled = []

    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "instructor": self.instructor,
            "time_slots": self.time_slots,
            "capacity": self.capacity,
            "content": self.content,
            "enrolled": self.enrolled
        }
