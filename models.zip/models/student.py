from models.user import User

class Student(User):
    def __init__(self, user_id, name, email, password):
        super().__init__(user_id, name, email, password, role="student")
        self.enrolled_courses = []

    def enroll(self, course_id):
        if course_id not in self.enrolled_courses:
            self.enrolled_courses.append(course_id)
